package project.oekakinoumi;
/*
* ユーザーを表すクラス
*/
public class User {
	//ユーザの名前
	private String name;
	/*
	* nameのセッター
	*/
	public void setName(String name) {
		this.name = name;
	}
	/*
	* nameのゲッター
	*/
	public String getName() {
		return this.name;
	}

}
